#!/usr/bin/env python2
# Echo client program
import socket

# HOST = '192.168.1.101'  # IP del servidor
HOST = 'localhost'  # IP del servidor
PORT = 3500             # Puerto del servidor
MSG = 'Hola Mundo!'

# Se crea un socket de tipo Internet (AF_INET) sobre TCP (SOCK_STREAM)
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
# Nos conectamos al host y puerto del servidor
s.connect((HOST, PORT))
# Enviamos un string
s.sendall(MSG)
# Leemos la respuesta del socket y lo cargamos en la variable 'data'
data = s.recv(1024)
# Cerramos el socket contra el server
s.close()
print 'Received', repr(data)
