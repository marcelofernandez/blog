#!/usr/bin/env python2
import socket

# HOST = '192.168.1.101'   # IP o Hostname donde escucha
HOST = ''   # IP o Hostname donde escucha
PORT = 3500              # Puerto de escucha
maxpedidos = 5           # Cantidad de pedidos acumulados (backlog)
bytes = 1024             # Cantidad maxima de bytes a aceptar

# Se crea un socket de tipo Internet (AF_INET) sobre TCP (SOCK_STREAM)
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# Seteo opcion REUSEADDR del sol_socket
# Ver https://hea-www.harvard.edu/~fine/Tech/addrinuse.html
s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

s.bind((HOST, PORT))     # Indicamos al socket la direccion IP y puerto
s.listen(maxpedidos)     # Indicamos el nro max de pedidos que aceptara
while True:
    client, address = s.accept() 	# Acepta las conexiones
    # Se obtienen los datos desde el socket cliente 
    data = client.recv(bytes)
    print 'Conexion desde: %s:%i' % (address[0], address[1])
    if data:
        client.send(data)        # Enviamos el echo al cliente 
    client.close()               # Cerramos el sock cliente
