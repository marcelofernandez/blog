#!/usr/bin/env python2
import socket

HOST = 'localhost'
PORT = 3500
bytes = 1024

s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
s.sendto('Taller II: Echo sobre UDP', (HOST, PORT))
data = s.recvfrom(bytes)
s.close()
print '-->', data[0]
