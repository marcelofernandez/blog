#!/usr/bin/env python2
import socket

HOST = 'localhost'    	# IP o Hostname donde escucha
PORT = 3500             # Puerto de escucha
bytes = 1024            # Cantidad maxima de bytes a aceptar

# Se crea un socket de tipo Internet (AF_INET) sobre UDP (SOCK_DGRAM)
s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
s.bind((HOST, PORT))    # Indicamos al socket la direccion IP y Port de escucha

while True:
    # Se obtienen los datos desde el sock cliente
    data, address = s.recvfrom(bytes)
    print 'Conexion desde: %s:%i' % (address[0], address[1])
    if data:
        s.sendto(data, address)    # Enviamos el echo al cliente 
